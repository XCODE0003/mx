import { defineStore } from "pinia";
import axiosClient from "../api/axios";
export const useTaskStore = defineStore("task", {
    state: () => ({
        loading: false,
        errors: null,
        selectedGrade: 'oge',
        selectedSubject: null,
        totalTasks: 0,
        subjects: [],
        grades: [
            { key: 'oge', value: 'ОГЭ' },
            { key: 'ege', value: 'ЕГЭ' }
        ],
        groups: []
    }),

    getters: {
        isLoading: (state) => state.loading,
    },

    actions: {

        clearErrors() {
            this.errors = null;
        },

        async getSubjects() {
            const response = await axiosClient.get(`/profile/subjects/${this.selectedGrade}`);
            this.subjects = response.data.map((subject) => ({
                key: subject.id,
                value: subject.name,
            }));
            this.selectedSubject = this.subjects[0].key;
        },

        async getGroups() {
            const response = await axiosClient.get(`/profile/groups/${this.selectedGrade}/${this.selectedSubject}`);
            this.groups = response.data.groups;
            this.totalTasks = response.data.total;
        },

        async getTasks(selectedGroup) {
            const response = await axiosClient.get(`/profile/tasks/${selectedGroup.id}`);
            this.tasks = response.data.tasks;
            // this.totalTasks = response.data.total;
            return response.data;
        },

    }

});
