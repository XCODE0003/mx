function copyToClipboard(text) {
    navigator.clipboard.writeText(text);
}



export { copyToClipboard };