<script setup>
import { useUserStore } from '../stores/userStore';
import { computed, onMounted } from 'vue';
import { Link } from '@inertiajs/vue3';
import { useTaskStore } from '../stores/taskStore';
const userStore = useUserStore();
const user = computed(() => userStore.currentUser);
onMounted(async () => {
    await useTaskStore().getSubjects();
    console.log(useTaskStore().subjects);
})
</script>


<template>
    <header>
        <div class="container">
            <div :class="{ 'autharization': user != null }" class="header_items">
                <div class="header_item">
                    <a href="/" class="header_item_logo"><img src="/assets/img/logo.svg" style="width: 100px;" alt=""></a>
                </div>
                <div class="header_item">
                    <ul class="header_item_navs">
                        <li class="header_item_nav"><a href="/">Главная</a></li>
                        <li class="header_item_nav"><a href="/profile">Создать вариант</a></li>
                        <li class="header_item_nav"><a href="/reviews">Отзывы</a></li>
                        <li class="header_item_nav"><a href="/news">Новости</a></li>
                        <li class="header_item_nav"><a href="/faq">FAQ</a></li>
                        <li class="header_item_nav"><a href="/banks">Банк заданий ФИПИ</a></li>
                    </ul>
                </div>
                <div class="header_item">
                    <div  class="header_item_buttons">
                        <a href="/signup"><button class="header_button">Регистрация</button></a>
                        <a href="/login"><button class="header_button">Вход</button></a>
                    </div>
                    <Link :href="`/profile`"  class="header_item_user">
                        <p class="header_item_user_email">{{ user?.email }}</p>
                        <img src="/assets/img/header_user.svg" alt="" class="header_item_user_icon">
                    </Link>
                </div>
                <svg class="header_mobile_burger" xmlns="http://www.w3.org/2000/svg" width="26" height="21" viewBox="0 0 26 21" fill="none">
                    <rect width="26" height="5" rx="2.5" fill="#8F70FF" />
                    <rect y="8" width="26" height="5" rx="2.5" fill="#8F70FF" />
                    <rect y="16" width="26" height="5" rx="2.5" fill="#8F70FF" />
                </svg>
                <div class="header_mobile">

                    <div class="header_mobile_menu">
                        <div class="header_mobile_menu_overlay"></div>
                        <div class="header_mobile_menu_rect">
                            <div class="header_mobile_menu_rect_content">
                                <div class="header_mobile_menu_rect_up">
                                    <a href="/" class="header_item_logo"><img src="/assets/img/logo.svg" alt=""></a>
                                    <svg class="header_mobile_menu_close" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M15.7002 0.737796C16.6839 -0.245634 18.2785 -0.245683 19.2622 0.737796C20.2459 1.72152 20.2459 3.31707 19.2622 4.3008L13.562 10L19.2622 15.7002C20.2459 16.684 20.2459 18.2785 19.2622 19.2622C18.2785 20.2459 16.6839 20.2459 15.7002 19.2622L9.99993 13.562L4.29969 19.2622C3.31594 20.2458 1.72134 20.2459 0.737652 19.2622C-0.245871 18.2785 -0.245897 16.6839 0.737652 15.7002L6.43789 10L0.737652 4.29981C-0.245777 3.31606 -0.245976 1.72142 0.737652 0.737796C1.72139 -0.245932 3.31694 -0.245932 4.30067 0.737796L9.99993 6.43702L15.7002 0.737796Z" fill="#8F70FF" />
                                    </svg>
                                </div>

                                <div class="header_item">
                                    <div class="header_item_buttons">
                                        <a href="/signup"><button class="header_button">Регистрация</button></a>
                                        <a href="login.html"><button class="header_button">Вход</button></a>
                                    </div>
                                    <div class="header_item_user">
                                        <p class="header_item_user_email">Examplemail@mail.com</p>
                                        <img src="/assets/img/header_user.svg" alt="" class="header_item_user_icon">
                                    </div>
                                </div>

                                <ul class="header_item_navs">
                                    <li class="header_item_nav"><a href="/">Главная</a></li>
                                    <li class="header_item_nav"><a href="profile_constructor.html">Создать вариант</a></li>
                                    <li class="header_item_nav"><a href="reviews.html">Отзывы</a></li>
                                    <li class="header_item_nav"><a href="news.html">Новости</a></li>
                                    <li class="header_item_nav"><a href="faq.html">FAQ</a></li>
                                    <li class="header_item_nav"><a href="banks.html">Банк заданий ФИПИ</a></li>
                                </ul>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
</template>

<style scoped>

</style>